create extension if not exists pgcrypto with schema extensions;

create table public.user_roles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  role text not null check (role in ('admin','employer','job_seeker')) default 'job_seeker',
  created_at timestamptz not null default now()
);
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text not null,
  full_name text not null default '',
  role text not null default 'job_seeker' check (role in ('admin','employer','job_seeker')),
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.employers (
  id uuid primary key default gen_random_uuid(), owner_id uuid references auth.users(id) on delete set null,
  name text not null, email text not null, website text, description text, status text not null default 'pending' check(status in ('pending','active','suspended')),
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.categories (
  id uuid primary key default gen_random_uuid(), name text not null unique, slug text not null unique,
  active boolean not null default true, created_at timestamptz not null default now()
);
create table public.jobs (
  id text primary key default ('lj-' || replace(gen_random_uuid()::text,'-','')),
  title text not null, company_name text not null, company_description text not null default '',
  location text not null default '', category text not null default 'Other', employment_type text not null default 'Full-time',
  experience_level text not null default '', salary_min numeric, salary_max numeric, salary_currency text not null default 'LKR',
  description text not null default '', responsibilities jsonb not null default '[]'::jsonb, requirements jsonb not null default '[]'::jsonb, benefits jsonb not null default '[]'::jsonb,
  posted_date date not null default current_date, closing_date date, apply_url text not null default '', source_name text not null default '', company_website text not null default '',
  is_featured boolean not null default false, is_remote boolean not null default false, is_published boolean not null default false, is_demo boolean not null default false,
  employer_id uuid references public.employers(id) on delete set null, created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create index jobs_published_created on public.jobs(is_published,created_at desc);
create table public.orders (
  id uuid primary key default gen_random_uuid(), employer_id uuid references public.employers(id) on delete set null,
  user_id uuid references auth.users(id) on delete set null, package text not null, amount numeric(12,2) not null check(amount>0), currency text not null default 'LKR',
  status text not null default 'pending' check(status in ('pending','paid','failed','refunded','cancelled')),
  payment_provider text not null default 'payhere', provider_reference text unique, payment_payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.payment_packages (
  id text primary key, title text not null, amount numeric(12,2) not null check(amount>0), currency text not null default 'LKR',
  active boolean not null default false, created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.ads (
  id uuid primary key default gen_random_uuid(), title text not null, placement text not null default 'android_home', creative_url text, target_url text,
  active boolean not null default false, starts_at timestamptz, ends_at timestamptz, created_at timestamptz not null default now()
);
create table public.app_settings (
  key text primary key, value jsonb not null default '{}'::jsonb, updated_at timestamptz not null default now(), updated_by uuid references auth.users(id) on delete set null
);
create table public.audit_logs (
  id bigint generated always as identity primary key, actor_id uuid references auth.users(id) on delete set null,
  action text not null, entity text not null, entity_id text, changes jsonb not null default '{}'::jsonb, created_at timestamptz not null default now()
);

create or replace function public.handle_auth_user_created() returns trigger language plpgsql security definer set search_path=public,pg_temp as $$
begin
  insert into public.profiles(id,email,full_name,role) values(new.id,coalesce(new.email,''),coalesce(new.raw_user_meta_data->>'full_name',''),'job_seeker') on conflict(id) do nothing;
  insert into public.user_roles(user_id,role) values(new.id,'job_seeker') on conflict(user_id) do nothing;
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_auth_user_created();

create or replace function public.sync_profile_role() returns trigger language plpgsql security definer set search_path=public,pg_temp as $$
begin
  if new.role is distinct from old.role then
    insert into public.user_roles(user_id,role) values(new.id,new.role) on conflict(user_id) do update set role=excluded.role;
  end if;
  return new;
end $$;
create trigger profiles_role_sync after update of role on public.profiles for each row execute function public.sync_profile_role();

create or replace function public.is_admin() returns boolean language sql stable security definer set search_path=public,pg_temp as $$
  select exists(select 1 from public.user_roles where user_id=auth.uid() and role='admin')
$$;
revoke all on function public.is_admin() from public;
grant execute on function public.is_admin() to anon, authenticated;

create or replace function public.write_audit_log() returns trigger language plpgsql security definer set search_path=public,pg_temp as $$
declare rec jsonb; target text;
begin
  if tg_op='DELETE' then rec=to_jsonb(old); target=coalesce(rec->>'id',rec->>'key',rec->>'user_id');
  elsif tg_op='UPDATE' then rec=to_jsonb(new); target=coalesce(rec->>'id',rec->>'key',rec->>'user_id');
  else rec=to_jsonb(new); target=coalesce(rec->>'id',rec->>'key',rec->>'user_id'); end if;
  insert into public.audit_logs(actor_id,action,entity,entity_id,changes) values(auth.uid(),lower(tg_op),tg_table_name,target,rec);
  if tg_op='DELETE' then return old; end if;
  return new;
end $$;
create trigger audit_jobs after insert or update or delete on public.jobs for each row execute function public.write_audit_log();
create trigger audit_employers after insert or update or delete on public.employers for each row execute function public.write_audit_log();
create trigger audit_orders after insert or update or delete on public.orders for each row execute function public.write_audit_log();
create trigger audit_payment_packages after insert or update or delete on public.payment_packages for each row execute function public.write_audit_log();

create or replace function public.protect_order_payment_status() returns trigger language plpgsql security definer set search_path=public,pg_temp as $$
begin
  if new.status is distinct from old.status and coalesce(current_setting('request.jwt.claim.role',true),'') <> 'service_role' then
    raise exception 'Payment status may only be changed by a verified payment callback';
  end if;
  return new;
end $$;
create trigger protect_order_status before update on public.orders for each row execute function public.protect_order_payment_status();
create trigger audit_ads after insert or update or delete on public.ads for each row execute function public.write_audit_log();
create trigger audit_categories after insert or update or delete on public.categories for each row execute function public.write_audit_log();
create trigger audit_profiles after insert or update or delete on public.profiles for each row execute function public.write_audit_log();
create trigger audit_roles after insert or update or delete on public.user_roles for each row execute function public.write_audit_log();
create trigger audit_settings after insert or update or delete on public.app_settings for each row execute function public.write_audit_log();

alter table public.user_roles enable row level security;
alter table public.profiles enable row level security;
alter table public.employers enable row level security;
alter table public.categories enable row level security;
alter table public.jobs enable row level security;
alter table public.orders enable row level security;
alter table public.payment_packages enable row level security;
alter table public.ads enable row level security;
alter table public.app_settings enable row level security;
alter table public.audit_logs enable row level security;

grant select on public.jobs, public.categories to anon, authenticated;
grant all on public.user_roles, public.profiles, public.employers, public.categories, public.jobs, public.orders, public.payment_packages, public.ads, public.app_settings, public.audit_logs to authenticated;
grant all on public.user_roles, public.profiles, public.employers, public.categories, public.jobs, public.orders, public.payment_packages, public.ads, public.app_settings, public.audit_logs to service_role;

create policy "admins manage roles" on public.user_roles for all to authenticated using(public.is_admin()) with check(public.is_admin());
create policy "admins manage profiles, users see own" on public.profiles for select to authenticated using(id=auth.uid() or public.is_admin());
create policy "admins update profiles" on public.profiles for all to authenticated using(public.is_admin()) with check(public.is_admin());
create policy "users create own profile" on public.profiles for insert to authenticated with check(id=auth.uid() and role='job_seeker');
create policy "admins manage employers" on public.employers for all to authenticated using(public.is_admin()) with check(public.is_admin());
create policy "owners view own employer" on public.employers for select to authenticated using(owner_id=auth.uid());
create policy "admins manage categories" on public.categories for all to authenticated using(public.is_admin()) with check(public.is_admin());
create policy "public view active categories" on public.categories for select to anon,authenticated using(active=true);
create policy "public read published jobs, admins manage all" on public.jobs for select to anon,authenticated using(is_published=true or public.is_admin());
create policy "admins manage jobs" on public.jobs for all to authenticated using(public.is_admin()) with check(public.is_admin());
create policy "admins manage orders" on public.orders for all to authenticated using(public.is_admin()) with check(public.is_admin());
create policy "owners view own orders" on public.orders for select to authenticated using(user_id=auth.uid());
create policy "admins manage payment packages" on public.payment_packages for all to authenticated using(public.is_admin()) with check(public.is_admin());
create policy "users see active payment packages" on public.payment_packages for select to authenticated using(active=true);
create policy "admins manage ads" on public.ads for all to authenticated using(public.is_admin()) with check(public.is_admin());
create policy "admins manage settings" on public.app_settings for all to authenticated using(public.is_admin()) with check(public.is_admin());
create policy "admins read audit logs" on public.audit_logs for select to authenticated using(public.is_admin());

insert into public.categories(name,slug) values ('IT & Software','it-software'),('Engineering','engineering'),('Finance','finance'),('Marketing','marketing'),('Healthcare','healthcare'),('Education','education'),('Customer Service','customer-service'),('Other','other') on conflict do nothing;
insert into public.app_settings(key,value) values
 ('monetization', '{"provider":"payhere","mode":"sandbox","enabled":false,"currency":"LKR"}'),
 ('advertising', '{"provider":"admob","enabled":false,"android_app_id":"","banner_unit_id":"","interstitial_unit_id":""}'),
 ('site', '{"name":"LankaJobs","default_job_duration_days":30}') on conflict do nothing;

-- First administrator bootstrap (run once in Supabase SQL Editor after creating its Auth user):
-- insert into public.user_roles(user_id,role) values ('AUTH_USER_UUID','admin');
-- update public.profiles set role='admin' where id='AUTH_USER_UUID';
