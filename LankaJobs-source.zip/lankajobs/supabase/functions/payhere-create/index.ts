import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { crypto } from 'https://deno.land/std@0.224.0/crypto/mod.ts';
import { encodeHex } from 'https://deno.land/std@0.224.0/encoding/hex.ts';
const cors={'Access-Control-Allow-Origin':Deno.env.get('ADMIN_ORIGIN')||'*','Access-Control-Allow-Headers':'authorization, x-client-info, apikey, content-type','Access-Control-Allow-Methods':'POST, OPTIONS'};
async function md5(value:string){return encodeHex(await crypto.subtle.digest('MD5',new TextEncoder().encode(value))).toUpperCase()}
Deno.serve(async req=>{if(req.method==='OPTIONS')return new Response('ok',{headers:cors});try{
 const auth=req.headers.get('Authorization');if(!auth)throw new Error('Authentication required');
 const jwt=auth.replace(/^Bearer\s+/i,'');const verifier=createClient(Deno.env.get('SUPABASE_URL')!,Deno.env.get('SUPABASE_ANON_KEY')!);
 const {data:{user},error:userError}=await verifier.auth.getUser(jwt);if(userError||!user)throw new Error('Authentication required');
 const supabase=createClient(Deno.env.get('SUPABASE_URL')!,Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
 const {packageId,employerId}=await req.json();if(typeof packageId!=='string'||!packageId)throw new Error('Select an available payment package');
 const {data:employer}=await supabase.from('employers').select('id,owner_id,name,email').eq('id',employerId).maybeSingle();
 const {data:role}=await supabase.from('user_roles').select('role').eq('user_id',user.id).maybeSingle();if(!employer||employer.owner_id!==user.id&&role?.role!=='admin')throw new Error('Employer access denied');
 const {data:plan}=await supabase.from('payment_packages').select('id,title,amount,currency').eq('id',packageId).eq('active',true).maybeSingle();if(!plan)throw new Error('Payment package is unavailable');
 const merchantId=Deno.env.get('PAYHERE_MERCHANT_ID'),secret=Deno.env.get('PAYHERE_MERCHANT_SECRET');if(!merchantId||!secret)throw new Error('PayHere credentials are not configured');
 const orderId=crypto.randomUUID(),currency=plan.currency,formatted=Number(plan.amount).toFixed(2),hash=await md5(merchantId+orderId+formatted+currency+await md5(secret));
 const {error}=await supabase.from('orders').insert({id:orderId,employer_id:employer.id,user_id:user.id,package:plan.title,amount:formatted,currency,status:'pending',payment_provider:'payhere'});if(error)throw error;
 const sandbox=(Deno.env.get('PAYHERE_MODE')||'sandbox')!=='live';const fields={merchant_id:merchantId,return_url:Deno.env.get('PAYHERE_RETURN_URL')||'',cancel_url:Deno.env.get('PAYHERE_CANCEL_URL')||'',notify_url:Deno.env.get('PAYHERE_NOTIFY_URL')||'',first_name:employer.name,last_name:'',email:employer.email,phone:'',address:'',city:'Colombo',country:'Sri Lanka',order_id:orderId,items:plan.title,currency,amount:formatted,hash};
 return Response.json({gateway:sandbox?'https://sandbox.payhere.lk/pay/checkout':'https://www.payhere.lk/pay/checkout',fields},{headers:cors});
 }catch(e){return Response.json({error:e instanceof Error?e.message:'Checkout failed'},{status:400,headers:cors})}});
