import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { crypto } from 'https://deno.land/std@0.224.0/crypto/mod.ts';
import { encodeHex } from 'https://deno.land/std@0.224.0/encoding/hex.ts';
async function md5(value:string){return encodeHex(await crypto.subtle.digest('MD5',new TextEncoder().encode(value))).toUpperCase()}
Deno.serve(async req=>{if(req.method!=='POST')return new Response('Method not allowed',{status:405});try{
 const form=await req.formData(),get=(key:string)=>String(form.get(key)||'');const merchantId=get('merchant_id'),orderId=get('order_id'),amount=get('payhere_amount'),currency=get('payhere_currency'),status=get('status_code'),received=get('md5sig');
 const secret=Deno.env.get('PAYHERE_MERCHANT_SECRET');if(!secret||merchantId!==Deno.env.get('PAYHERE_MERCHANT_ID'))return new Response('Invalid merchant',{status:400});
 const expected=await md5(merchantId+orderId+amount+currency+status+await md5(secret));if(expected!==received.toUpperCase())return new Response('Invalid signature',{status:400});
 const supabase=createClient(Deno.env.get('SUPABASE_URL')!,Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
 const {data:order,error}=await supabase.from('orders').select('id,amount,currency,status').eq('id',orderId).maybeSingle();if(error||!order)return new Response('Order not found',{status:404});
 if(Number(order.amount).toFixed(2)!==Number(amount).toFixed(2)||order.currency!==currency)return new Response('Payment mismatch',{status:400});
 const next=status==='2'?'paid':status==='-1'?'cancelled':status==='-2'?'failed':status==='-3'?'refunded':'pending';
 if(order.status==='pending'&&next!=='pending'){const {error:updateError}=await supabase.from('orders').update({status:next,provider_reference:get('payment_id')||null,payment_payload:{method:get('method'),status_code:status,paid_at:get('paid_at')}}).eq('id',orderId).eq('status','pending');if(updateError)throw updateError}
 return new Response('OK',{status:200});
 }catch(e){console.error('PayHere notification error',e);return new Response('Notification processing failed',{status:500})}});
