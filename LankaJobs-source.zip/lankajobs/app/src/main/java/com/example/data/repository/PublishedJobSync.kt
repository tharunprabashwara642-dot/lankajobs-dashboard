package com.example.data.repository

import android.util.Log
import com.example.BuildConfig
import com.example.data.local.dao.JobDao
import com.example.data.local.AppDatabase
import com.example.data.local.entity.JobEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.room.withTransaction
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Fetches only public, published Supabase rows and stores them in Room for offline reading. */
class PublishedJobSync(private val database: AppDatabase) {
    private val jobDao: JobDao = database.jobDao()
    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .build()

    suspend fun refresh() = withContext(Dispatchers.IO) {
        val base = BuildConfig.SUPABASE_URL.trimEnd('/')
        val anon = BuildConfig.SUPABASE_ANON_KEY
        if (base.isBlank() || anon.isBlank()) return@withContext
        try {
            val request = Request.Builder()
                .url("$base/rest/v1/jobs?select=*&is_published=eq.true&order=created_at.desc&limit=500")
                .header("apikey", anon)
                .header("Accept", "application/json")
                .build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) throw IllegalStateException("Supabase returned HTTP ${response.code}")
                val body = response.body?.string().orEmpty()
                val data = JSONArray(body)
                val jobs = (0 until data.length()).map { index -> data.getJSONObject(index).toEntity() }
                database.withTransaction {
                    jobDao.hideJobsBeforeRemoteReconcile()
                    if (jobs.isNotEmpty()) jobDao.insertJobs(jobs)
                }
            }
        } catch (error: Exception) {
            // Network/configuration failure keeps the most recent Room snapshot and demo fallback.
            Log.i("LankaJobsSync", "Published jobs refresh skipped: ${error.message}")
        }
    }

    private fun JSONObject.toEntity(): JobEntity = JobEntity(
        id = optString("id"),
        title = optString("title"),
        companyName = optString("company_name"),
        companyDescription = optString("company_description"),
        location = optString("location"),
        category = optString("category", "Other"),
        employmentType = optString("employment_type", "Full-time"),
        experienceLevel = optString("experience_level"),
        salaryMin = nullableDouble("salary_min"),
        salaryMax = nullableDouble("salary_max"),
        salaryCurrency = optString("salary_currency", "LKR"),
        description = optString("description"),
        responsibilities = stringArray("responsibilities"),
        requirements = stringArray("requirements"),
        benefits = stringArray("benefits"),
        postedDate = optString("posted_date"),
        closingDate = if (isNull("closing_date")) "" else optString("closing_date"),
        applyUrl = optString("apply_url"),
        sourceName = optString("source_name"),
        companyWebsite = optString("company_website"),
        isFeatured = optBoolean("is_featured"),
        isRemote = optBoolean("is_remote"),
        isPublished = true,
        isDemo = false,
        createdAt = runCatching { java.time.Instant.parse(optString("created_at")).toEpochMilli() }.getOrDefault(System.currentTimeMillis())
    )

    private fun JSONObject.nullableDouble(key: String): Double? = if (isNull(key)) null else optDouble(key).takeIf { it.isFinite() }
    private fun JSONObject.stringArray(key: String): String = when (val value = opt(key)) {
        is JSONArray -> (0 until value.length()).mapNotNull { value.optString(it).takeIf(String::isNotBlank) }.joinToString("\n")
        is String -> value
        else -> ""
    }
}
